from enum import Enum, auto

class layers(Enum):
    BACKGROUND = auto(),
    TEXT = auto(),
    FULL = auto()
    