from styler.core.style import style

_TEMPLATE = "\033[1m{}\033[22m"
bold = style(_TEMPLATE)